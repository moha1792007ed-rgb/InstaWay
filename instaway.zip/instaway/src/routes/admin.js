import { Router } from 'express';
import bcrypt from 'bcryptjs';
import rateLimit from 'express-rate-limit';
import { pool, tx, audit } from '../db.js';
import { config } from '../config.js';
import { AppError, wrap } from '../errors.js';
import { requireAdmin, csrfGuard, setAuthCookie, COOKIE } from '../auth.js';
import { loginSchema, tripSchema, adminBookingsQuery, statsQuery, uuid, fareFor } from '../validate.js';
import { maybeConfirmTrip, maybeUnconfirmTrip, cancelTrip, BOOKING_VIEW, BOOKING_GROUP } from '../services.js';

export const adminRouter = Router();
const ok = (res, data, status = 200) => res.status(status).json({ success: true, data });
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 12); // equalises timing for unknown usernames
const loginLimiter = rateLimit({
  windowMs: 15 * 60_000, limit: 10, standardHeaders: true, legacyHeaders: false,
  handler: (req, res, next) => next(new AppError(429, 'RATE_LIMITED', 'محاولات كتير، حاول بعد شوية.')),
});

adminRouter.use(csrfGuard);

adminRouter.post('/login', loginLimiter, wrap(async (req, res) => {
  const { username, password } = loginSchema.parse(req.body);
  const a = (await pool.query('SELECT * FROM admins WHERE username=$1', [username])).rows[0];
  if (a?.locked_until && a.locked_until > new Date()) throw new AppError(429, 'ACCOUNT_LOCKED', 'الحساب مقفول مؤقتًا. حاول بعد شوية.');
  const good = await bcrypt.compare(password, a?.password_hash ?? DUMMY_HASH);
  if (!a || !a.active || !good) {
    if (a) {
      await pool.query(
        `UPDATE admins SET failed_attempts=failed_attempts+1,
           locked_until = CASE WHEN failed_attempts+1 >= 5 THEN now() + interval '15 minutes' ELSE locked_until END,
           failed_attempts = CASE WHEN failed_attempts+1 >= 5 THEN 0 ELSE failed_attempts+1 END WHERE id=$1`, [a.id]);
    }
    await audit(pool, { actor: `admin:${username}`, action: 'LOGIN_FAILED', ip: req.ip });
    throw new AppError(401, 'INVALID_CREDENTIALS', 'بيانات الدخول غير صحيحة.');
  }
  await pool.query('UPDATE admins SET failed_attempts=0, locked_until=NULL WHERE id=$1', [a.id]);
  setAuthCookie(res, a);
  await audit(pool, { actor: `admin:${username}`, action: 'LOGIN_OK', ip: req.ip });
  ok(res, { username: a.username });
}));

adminRouter.post('/logout', (req, res) => { res.clearCookie(COOKIE, { path: '/api/admin' }); ok(res, { loggedOut: true }); });

adminRouter.use(requireAdmin);

adminRouter.get('/me', (req, res) => ok(res, { username: req.admin.username }));

adminRouter.get('/stats', wrap(async (req, res) => {
  const { days } = statsQuery.parse(req.query);
  const [b, t, r, d] = await Promise.all([
    pool.query(
      `SELECT count(*)::int AS total,
              count(*) FILTER (WHERE status='PAID')::int AS paid,
              count(*) FILTER (WHERE status='PENDING_PAYMENT' AND hold_expires_at > now())::int AS pending,
              count(*) FILTER (WHERE status='PENDING_PAYMENT' AND hold_expires_at > now() AND pay_reference IS NOT NULL)::int AS awaiting_review,
              count(*) FILTER (WHERE status='EXPIRED')::int AS expired,
              count(*) FILTER (WHERE status IN ('CANCELLED','REFUND_DUE','REFUNDED'))::int AS cancelled,
              count(*) FILTER (WHERE status='REFUND_DUE')::int AS refund_due,
              COALESCE(sum(total_egp) FILTER (WHERE status='REFUND_DUE'),0)::int AS refund_due_egp,
              COALESCE(sum(total_egp) FILTER (WHERE status='PAID'),0)::int AS revenue
       FROM bookings WHERE created_at >= now() - make_interval(days => $1::int)`, [days]),
    pool.query(
      `SELECT count(*)::int AS total,
              count(*) FILTER (WHERE status='CANCELLED')::int AS cancelled,
              count(*) FILTER (WHERE status IN ('CONFIRMED','COMPLETED'))::int AS confirmed,
              count(*) FILTER (WHERE status='COMPLETED')::int AS completed
       FROM trips WHERE depart_at >= now() - make_interval(days => $1::int)`, [days]),
    // Occupancy and route performance only count trips that already departed and were not cancelled.
    pool.query(
      `SELECT t.origin, t.destination, count(*)::int AS trips, sum(t.capacity)::int AS capacity,
              COALESCE(sum(p.seats),0)::int AS paid_seats, COALESCE(sum(p.seats * t.price_egp),0)::int AS revenue
       FROM trips t LEFT JOIN LATERAL (
         SELECT count(*)::int AS seats FROM booking_seats bs JOIN bookings b ON b.id=bs.booking_id
         WHERE bs.trip_id=t.id AND bs.active AND b.status='PAID') p ON true
       WHERE t.depart_at BETWEEN now() - make_interval(days => $1::int) AND now() AND t.status <> 'CANCELLED'
       GROUP BY t.origin, t.destination ORDER BY revenue DESC, paid_seats DESC`, [days]),
    pool.query(
      `SELECT to_char(g.d, 'YYYY-MM-DD') AS day, COALESCE(x.bookings,0)::int AS bookings, COALESCE(x.revenue,0)::int AS revenue
       FROM generate_series((now() AT TIME ZONE 'Africa/Cairo')::date - ($1::int - 1), (now() AT TIME ZONE 'Africa/Cairo')::date, interval '1 day') AS g(d)
       LEFT JOIN (
         SELECT (created_at AT TIME ZONE 'Africa/Cairo')::date AS day, count(*) AS bookings,
                sum(total_egp) FILTER (WHERE status='PAID') AS revenue
         FROM bookings WHERE created_at >= now() - make_interval(days => $1::int) GROUP BY 1) x ON x.day = g.d::date
       ORDER BY g.d`, [days]),
  ]);
  const B = b.rows[0], T = t.rows[0];
  const pct = (a, z) => (z > 0 ? Math.round((a / z) * 1000) / 10 : null);
  const cap = r.rows.reduce((s, x) => s + x.capacity, 0), seats = r.rows.reduce((s, x) => s + x.paid_seats, 0);
  ok(res, {
    days,
    kpis: {
      revenueEgp: B.revenue, bookings: B.total, paid: B.paid, pending: B.pending, awaitingReview: B.awaiting_review,
      expired: B.expired, refundDue: B.refund_due, refundDueEgp: B.refund_due_egp,
      cancellationRatePct: pct(B.cancelled, B.total), occupancyPct: pct(seats, cap),
      trips: T.total, tripsCancelled: T.cancelled, completionRatePct: pct(T.completed, T.confirmed),
    },
    routes: r.rows.map((x) => ({ from: x.origin, to: x.destination, trips: x.trips, paidSeats: x.paid_seats, capacity: x.capacity, occupancyPct: pct(x.paid_seats, x.capacity), revenueEgp: x.revenue })),
    daily: d.rows,
  });
}));

adminRouter.get('/trips', wrap(async (req, res) => {
  const { rows } = await pool.query(
    `SELECT t.*, COALESCE(p.paid,0)::int AS paid_seats, COALESCE(p.pending,0)::int AS pending_seats
     FROM trips t LEFT JOIN LATERAL (
       SELECT count(*) FILTER (WHERE b.status='PAID') AS paid,
              count(*) FILTER (WHERE b.status='PENDING_PAYMENT' AND b.hold_expires_at > now()) AS pending
       FROM booking_seats bs JOIN bookings b ON b.id=bs.booking_id WHERE bs.trip_id=t.id AND bs.active) p ON true
     WHERE t.depart_at > now() - interval '1 day' ORDER BY t.depart_at LIMIT 200`);
  ok(res, rows.map((t) => ({ ...t, occupancyPct: Math.round((t.paid_seats / t.capacity) * 100) })));
}));

adminRouter.post('/trips', wrap(async (req, res) => {
  const t = tripSchema.parse(req.body);
  const min = t.capacity; // a trip is confirmed only when every seat is paid
  const deadline = t.bookingDeadline ?? new Date(t.departAt.getTime() - config.deadlineHoursBefore * 3600e3);
  if (deadline <= new Date() || deadline > t.departAt) throw new AppError(400, 'INVALID_TIMES', 'مواعيد الرحلة أو آخر ميعاد للحجز غير منطقية.');
  const id = await tx(async (c) => {
    const r = await c.query(
      `INSERT INTO trips(origin,destination,depart_at,booking_deadline,capacity,price_egp,min_passengers)
       VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id`, [t.origin, t.destination, t.departAt, deadline, t.capacity, t.priceEgp ?? fareFor(t.origin, t.destination), min]);
    await audit(c, { actor: `admin:${req.admin.username}`, action: 'TRIP_CREATED', entity: 'trip', entityId: r.rows[0].id, ip: req.ip });
    return r.rows[0].id;
  });
  ok(res, { id }, 201);
}));

adminRouter.post('/trips/:id/cancel', wrap(async (req, res) => {
  const id = uuid.parse(req.params.id);
  await tx(async (c) => {
    const t = (await c.query('SELECT status FROM trips WHERE id=$1 FOR UPDATE', [id])).rows[0];
    if (!t) throw new AppError(404, 'NOT_FOUND', 'الرحلة مش موجودة.');
    if (!['OPEN', 'CONFIRMED'].includes(t.status)) throw new AppError(409, 'INVALID_STATE', 'مينفعش تلغي الرحلة دي.');
    await cancelTrip(c, id);
    await audit(c, { actor: `admin:${req.admin.username}`, action: 'TRIP_CANCELLED', entity: 'trip', entityId: id, ip: req.ip });
  });
  ok(res, { cancelled: true });
}));

adminRouter.get('/bookings', wrap(async (req, res) => {
  const q = adminBookingsQuery.parse(req.query);
  const { rows } = await pool.query(
    `${BOOKING_VIEW} WHERE ($1::uuid IS NULL OR b.trip_id=$1) AND ($2::text IS NULL OR b.status=$2)
     ${BOOKING_GROUP} ORDER BY b.created_at DESC LIMIT $3 OFFSET $4`, [q.tripId ?? null, q.status ?? null, q.limit, q.offset]);
  ok(res, rows);
}));

async function bookingAction(req, res, { from, to, action, reactivate = false }) {
  const id = uuid.parse(req.params.id);
  try {
    const out = await tx(async (c) => {
      const b = (await c.query('SELECT id, trip_id, status FROM bookings WHERE id=$1 FOR UPDATE', [id])).rows[0];
      if (!b) throw new AppError(404, 'NOT_FOUND', 'الحجز مش موجود.');
      if (!from.includes(b.status)) throw new AppError(409, 'INVALID_STATE', `الحالة الحالية (${b.status}) لا تسمح بالإجراء ده.`);
      const t = (await c.query('SELECT status FROM trips WHERE id=$1 FOR UPDATE', [b.trip_id])).rows[0];
      if (reactivate) {
        if (t.status === 'CANCELLED') throw new AppError(409, 'TRIP_CANCELLED', 'الرحلة اتلغت. حوّل الحجز لاسترداد.');
        // Money arrived after the hold expired: take the seats back if still free (unique index decides).
        await c.query('UPDATE booking_seats SET active=true WHERE booking_id=$1', [id]);
      }
      await c.query('UPDATE bookings SET status=$2, updated_at=now() WHERE id=$1', [id, to]);
      const confirmed = to === 'PAID' ? await maybeConfirmTrip(c, b.trip_id) : false;
      let reopened = false;
      if (to === 'REFUND_DUE') { // free the seats, and reopen the trip if too many paid seats are now missing
        await c.query('UPDATE booking_seats SET active=false WHERE booking_id=$1', [id]);
        reopened = await maybeUnconfirmTrip(c, b.trip_id);
      }
      await audit(c, { actor: `admin:${req.admin.username}`, action, entity: 'booking', entityId: id, meta: { from: b.status, to, tripConfirmed: confirmed, tripReopened: reopened }, ip: req.ip });
      return { status: to, tripConfirmed: confirmed, tripReopened: reopened };
    });
    ok(res, out);
  } catch (e) {
    if (e.code === '23505') throw new AppError(409, 'SEATS_NO_LONGER_AVAILABLE', 'الكراسي اتحجزت لحد تاني بعد انتهاء المهلة. حوّل الحجز لاسترداد.');
    throw e;
  }
}

adminRouter.post('/bookings/:id/confirm-payment', wrap((req, res) =>
  bookingAction(req, res, { from: ['PENDING_PAYMENT', 'EXPIRED'], to: 'PAID', action: 'PAYMENT_CONFIRMED', reactivate: true })));
adminRouter.post('/bookings/:id/mark-refund-due', wrap((req, res) =>
  bookingAction(req, res, { from: ['PAID', 'EXPIRED'], to: 'REFUND_DUE', action: 'REFUND_MARKED_DUE' })));
adminRouter.post('/bookings/:id/mark-refunded', wrap((req, res) =>
  bookingAction(req, res, { from: ['REFUND_DUE'], to: 'REFUNDED', action: 'REFUNDED' })));
