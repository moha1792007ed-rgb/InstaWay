import { Router } from 'express';
import crypto from 'node:crypto';
import rateLimit from 'express-rate-limit';
import { pool, tx, audit } from '../db.js';
import { config } from '../config.js';
import { AppError, wrap } from '../errors.js';
import { uuid, code as codeSchema, bookSchema, tripsQuery, phoneBody, paymentRefBody } from '../validate.js';
import { releaseExpiredHolds, maybeUnconfirmTrip, LIVE_BOOKING, BOOKING_VIEW, BOOKING_GROUP } from '../services.js';

export const publicRouter = Router();

const ok = (res, data, status = 200) => res.status(status).json({ success: true, data });
const limiter = (minutes, limit) => rateLimit({
  windowMs: minutes * 60_000, limit, standardHeaders: true, legacyHeaders: false,
  handler: (req, res, next) => next(new AppError(429, 'RATE_LIMITED', 'محاولات كتير، استنى شوية وحاول تاني.')),
});
const readLimiter = limiter(15, 120);
const bookLimiter = limiter(60, config.bookRateMax);
const lookupLimiter = limiter(15, 30);

const ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; // no look-alike chars
const newCode = () => Array.from(crypto.randomBytes(8), (b) => ALPHABET[b % ALPHABET.length]).join('');

const present = (r) => ({
  code: r.code, status: r.status, seats: r.seats, totalEgp: r.total_egp, payMethod: r.pay_method,
  holdExpiresAt: r.hold_expires_at, trip: { from: r.origin, to: r.destination, departAt: r.depart_at },
});

async function findOwned(c, code, phone, lock = false) {
  const r = await c.query(`${BOOKING_VIEW} WHERE b.code=$1 AND b.phone=$2 ${BOOKING_GROUP}`, [code, phone]);
  const row = r.rows[0];
  if (!row) throw new AppError(404, 'BOOKING_NOT_FOUND', 'مفيش حجز بالبيانات دي.'); // same answer for wrong code or phone
  if (lock) await c.query('SELECT 1 FROM bookings WHERE id=$1 FOR UPDATE', [row.id]);
  return row;
}

publicRouter.get('/config', (req, res) => ok(res, { holdMinutes: config.holdMinutes }));

publicRouter.get('/trips', readLimiter, wrap(async (req, res) => {
  const q = tripsQuery.parse(req.query);
  const { rows } = await pool.query(
    `SELECT t.id, t.depart_at, t.price_egp, t.status,
            t.capacity - COALESCE(s.n, 0) AS seats_free
     FROM trips t
     LEFT JOIN LATERAL (
       SELECT count(*)::int AS n FROM booking_seats bs JOIN bookings b ON b.id=bs.booking_id
       WHERE bs.trip_id=t.id AND bs.active AND ${LIVE_BOOKING}) s ON true
     WHERE t.origin=$1 AND t.destination=$2
       AND t.depart_at >= ($3::date::timestamp AT TIME ZONE 'Africa/Cairo')
       AND t.depart_at <  (($3::date + 1)::timestamp AT TIME ZONE 'Africa/Cairo')
       AND t.status IN ('OPEN','CONFIRMED') AND t.booking_deadline > now()
     ORDER BY t.depart_at`, [q.from, q.to, q.date]);
  ok(res, rows.map((r) => ({ id: r.id, departAt: r.depart_at, priceEgp: r.price_egp, seatsFree: r.seats_free, status: r.status })));
}));

publicRouter.get('/trips/:id/seats', readLimiter, wrap(async (req, res) => {
  const id = uuid.parse(req.params.id);
  const { rows } = await pool.query(
    `SELECT bs.seat_no FROM booking_seats bs JOIN bookings b ON b.id=bs.booking_id
     WHERE bs.trip_id=$1 AND bs.active AND ${LIVE_BOOKING} ORDER BY bs.seat_no`, [id]);
  ok(res, { taken: rows.map((r) => r.seat_no) });
}));

publicRouter.post('/trips/:id/book', bookLimiter, wrap(async (req, res) => {
  const id = uuid.parse(req.params.id);
  const body = bookSchema.parse(req.body);
  if (body.website) return ok(res, { ignored: true }, 201); // honeypot: bots get a fake success, nothing is stored
  const key = req.get('Idempotency-Key') ?? '';
  if (!/^[A-Za-z0-9-]{16,64}$/.test(key)) throw new AppError(400, 'IDEMPOTENCY_KEY_REQUIRED', 'طلب غير مكتمل، حدّث الصفحة وحاول تاني.');

  try {
    const out = await tx(async (c) => {
      const dup = (await c.query(`${BOOKING_VIEW} WHERE b.idempotency_key=$1 ${BOOKING_GROUP}`, [key])).rows[0];
      if (dup) {
        if (dup.phone !== body.phone) throw new AppError(409, 'IDEMPOTENCY_CONFLICT', 'الطلب ده اتبعت قبل كده ببيانات مختلفة.');
        return { row: dup, replay: true };
      }
      // Row lock on the trip serialises concurrent bookings; the partial unique index is the second safety net.
      const t = (await c.query('SELECT *, booking_deadline <= now() AS closed FROM trips WHERE id=$1 FOR UPDATE', [id])).rows[0];
      if (!t || !['OPEN', 'CONFIRMED'].includes(t.status) || t.closed) throw new AppError(409, 'TRIP_NOT_AVAILABLE', 'الرحلة دي مش متاحة للحجز دلوقتي.');
      if (body.seats.some((s) => s > t.capacity)) throw new AppError(400, 'INVALID_SEAT', 'رقم كرسي غير موجود في العربية دي.');
      await releaseExpiredHolds(c, id);
      const pend = (await c.query(
        `SELECT count(*)::int AS n FROM bookings WHERE phone=$1 AND status='PENDING_PAYMENT' AND hold_expires_at > now()`, [body.phone])).rows[0].n;
      if (pend >= config.maxPendingPerPhone) throw new AppError(429, 'TOO_MANY_PENDING', 'عندك حجوزات كتير مستنية الدفع. ادفع أو استنى لحد ما تنتهي.');

      const total = t.price_egp * body.seats.length; // price always comes from the server
      const ins = await c.query(
        `INSERT INTO bookings(code,trip_id,name,phone,total_egp,pay_method,hold_expires_at,idempotency_key)
         VALUES($1,$2,$3,$4,$5,$6, now() + make_interval(mins => $7), $8) RETURNING id`,
        [newCode(), id, body.name, body.phone, total, body.payMethod, config.holdMinutes, key]);
      await c.query('INSERT INTO booking_seats(booking_id,trip_id,seat_no) SELECT $1,$2,unnest($3::int[])', [ins.rows[0].id, id, body.seats]);
      await audit(c, { actor: 'passenger', action: 'BOOKING_CREATED', entity: 'booking', entityId: ins.rows[0].id, ip: req.ip });
      const row = (await c.query(`${BOOKING_VIEW} WHERE b.id=$1 ${BOOKING_GROUP}`, [ins.rows[0].id])).rows[0];
      return { row, replay: false };
    });
    ok(res, {
      booking: present(out.row),
      payment: { method: out.row.pay_method, wallet: config.walletNumber, amountEgp: out.row.total_egp, holdMinutes: config.holdMinutes },
    }, out.replay ? 200 : 201);
  } catch (e) {
    if (e.code === '23505' && String(e.constraint).includes('booking_seats_active_seat')) throw new AppError(409, 'SEAT_TAKEN', 'واحد أو أكتر من الكراسي دي اتحجز. اختار كراسي تانية.');
    if (e.code === '23505') throw new AppError(409, 'CONFLICT_RETRY', 'حصل تعارض، حاول تاني.');
    throw e;
  }
}));

publicRouter.post('/bookings/:code/lookup', lookupLimiter, wrap(async (req, res) => {
  const code = codeSchema.parse(req.params.code);
  const { phone } = phoneBody.parse(req.body);
  ok(res, present(await findOwned(pool, code, phone)));
}));

publicRouter.post('/bookings/:code/payment', lookupLimiter, wrap(async (req, res) => {
  const code = codeSchema.parse(req.params.code);
  const { phone, reference } = paymentRefBody.parse(req.body);
  await tx(async (c) => {
    const b = await findOwned(c, code, phone, true);
    if (b.status !== 'PENDING_PAYMENT') throw new AppError(409, 'INVALID_STATE', 'الحجز ده مش مستني دفع.');
    await c.query('UPDATE bookings SET pay_reference=$2, updated_at=now() WHERE id=$1', [b.id, reference]);
    await audit(c, { actor: 'passenger', action: 'PAYMENT_REFERENCE_SUBMITTED', entity: 'booking', entityId: b.id, ip: req.ip });
  });
  ok(res, { received: true });
}));

publicRouter.post('/bookings/:code/cancel', lookupLimiter, wrap(async (req, res) => {
  const code = codeSchema.parse(req.params.code);
  const { phone } = phoneBody.parse(req.body);
  const status = await tx(async (c) => {
    const b = await findOwned(c, code, phone, true);
    let next;
    if (b.status === 'PENDING_PAYMENT') next = 'CANCELLED';
    else if (b.status === 'PAID') {
      const { rows } = await c.query(`SELECT depart_at - now() > make_interval(hours => $2) AS allowed FROM trips WHERE id=$1`, [b.trip_id, config.cancelCutoffHours]);
      if (!rows[0].allowed) throw new AppError(409, 'CANCELLATION_CLOSED', 'فات ميعاد الإلغاء المسموح لالرحلة دي.');
      next = 'REFUND_DUE';
    } else throw new AppError(409, 'INVALID_STATE', 'مينفعش تلغي الحجز ده.');
    await c.query('UPDATE bookings SET status=$2, updated_at=now() WHERE id=$1', [b.id, next]);
    await c.query('UPDATE booking_seats SET active=false WHERE booking_id=$1', [b.id]);
    const reopened = await maybeUnconfirmTrip(c, b.trip_id);
    await audit(c, { actor: 'passenger', action: 'BOOKING_CANCELLED', entity: 'booking', entityId: b.id, meta: { next, tripReopened: reopened }, ip: req.ip });
    return next;
  });
  ok(res, { status });
}));
