import { z } from 'zod';

export const ASSIUT = 'أسيوط';
export const CITIES = ['أسيوط', 'ديروط', 'القوصية', 'منفلوط'];
// Fixed fare per seat, by the non-Assiut end of the trip (same price in both directions).
export const FARES = { 'ديروط': 40, 'القوصية': 30, 'منفلوط': 15 };
export const fareFor = (origin, destination) => FARES[origin === ASSIUT ? destination : origin];

export const uuid = z.string().uuid();
export const phone = z.string().trim().regex(/^01[0125]\d{8}$/, 'رقم تليفون غير صحيح');
export const code = z.string().trim().toUpperCase().regex(/^[A-Z0-9]{8}$/, 'كود الحجز غير صحيح');
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/).refine((s) => new Date(`${s}T00:00:00Z`).toISOString().startsWith(s), 'تاريخ غير صحيح');

export const tripsQuery = z.object({ from: z.enum(CITIES), to: z.enum(CITIES), date: isoDate });

export const bookSchema = z.object({
  name: z.string().trim().min(2).max(60).regex(/^[\p{L}\s.'-]+$/u, 'الاسم يحتوي على رموز غير مسموحة'),
  phone,
  seats: z.array(z.number().int().min(1).max(14)).min(1).max(4)
    .refine((a) => new Set(a).size === a.length, 'كراسي مكررة'),
  payMethod: z.enum(['VODAFONE', 'ETISALAT', 'ORANGE', 'INSTAPAY']),
  website: z.string().max(200).optional(), // honeypot
}).strict();

export const phoneBody = z.object({ phone }).strict();
export const paymentRefBody = z.object({
  phone,
  reference: z.string().trim().min(4).max(40).regex(/^[\p{L}\p{N}\-_. ]+$/u, 'رقم العملية غير صحيح'),
}).strict();

export const loginSchema = z.object({ username: z.string().trim().min(3).max(40), password: z.string().min(1).max(200) }).strict();

export const tripSchema = z.object({
  origin: z.enum(CITIES),
  destination: z.enum(CITIES),
  priceEgp: z.number().int().min(1).max(5000).optional(), // empty = default fare for the route
  departAt: z.coerce.date(),
  capacity: z.number().int().min(1).max(14).default(14),
  bookingDeadline: z.coerce.date().optional(),
}).strict().refine((t) => t.origin !== t.destination, 'نقطة التحرك والوصول لازم يختلفوا')
  .refine((t) => t.origin === ASSIUT || t.destination === ASSIUT, 'لازم أسيوط تكون نقطة التحرك أو الوصول');

export const statsQuery = z.object({ days: z.coerce.number().int().min(1).max(365).default(30) });

export const adminBookingsQuery = z.object({
  tripId: uuid.optional(),
  status: z.enum(['PENDING_PAYMENT', 'PAID', 'EXPIRED', 'CANCELLED', 'REFUND_DUE', 'REFUNDED']).optional(),
  limit: z.coerce.number().int().min(1).max(100).default(50),
  offset: z.coerce.number().int().min(0).default(0),
});
