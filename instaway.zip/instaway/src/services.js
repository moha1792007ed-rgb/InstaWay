// Shared business rules. Every function expects to run inside a transaction (client `c`).

export async function releaseExpiredHolds(c, tripId = null) {
  const r = await c.query(
    `UPDATE bookings SET status='EXPIRED', updated_at=now()
     WHERE status='PENDING_PAYMENT' AND hold_expires_at <= now() AND ($1::uuid IS NULL OR trip_id=$1)
     RETURNING id`, [tripId]);
  if (r.rowCount) {
    await c.query('UPDATE booking_seats SET active=false WHERE booking_id = ANY($1::uuid[])', [r.rows.map((x) => x.id)]);
  }
  return r.rowCount;
}

// OPEN -> CONFIRMED once paid seats reach the trip's minimum.
export async function maybeConfirmTrip(c, tripId) {
  const r = await c.query(
    `UPDATE trips t SET status='CONFIRMED'
     WHERE t.id=$1 AND t.status='OPEN' AND
       (SELECT count(*) FROM booking_seats bs JOIN bookings b ON b.id=bs.booking_id
        WHERE bs.trip_id=t.id AND bs.active AND b.status='PAID') >= t.min_passengers
     RETURNING id`, [tripId]);
  return r.rowCount === 1;
}

// CONFIRMED -> OPEN when two or more paid seats are missing (one cancellation is tolerated).
export async function maybeUnconfirmTrip(c, tripId) {
  const r = await c.query(
    `UPDATE trips t SET status='OPEN'
     WHERE t.id=$1 AND t.status='CONFIRMED' AND
       (SELECT count(*) FROM booking_seats bs JOIN bookings b ON b.id=bs.booking_id
        WHERE bs.trip_id=t.id AND bs.active AND b.status='PAID') < t.capacity - 1
     RETURNING id`, [tripId]);
  return r.rowCount === 1;
}

// Cancels a trip: paid bookings become REFUND_DUE, unpaid ones CANCELLED, seats are released.
export async function cancelTrip(c, tripId) {
  await c.query(`UPDATE trips SET status='CANCELLED' WHERE id=$1 AND status IN ('OPEN','CONFIRMED')`, [tripId]);
  await c.query(
    `UPDATE bookings SET status = CASE WHEN status='PAID' THEN 'REFUND_DUE' ELSE 'CANCELLED' END, updated_at=now()
     WHERE trip_id=$1 AND status IN ('PAID','PENDING_PAYMENT')`, [tripId]);
  await c.query('UPDATE booking_seats SET active=false WHERE trip_id=$1', [tripId]);
}

export const LIVE_BOOKING = `(b.status='PAID' OR (b.status='PENDING_PAYMENT' AND b.hold_expires_at > now()))`;

export const BOOKING_VIEW = `
  SELECT b.id, b.code, b.name, b.phone, b.status, b.total_egp, b.pay_method, b.pay_reference,
         b.hold_expires_at, b.trip_id, t.origin, t.destination, t.depart_at,
         COALESCE(array_agg(bs.seat_no ORDER BY bs.seat_no) FILTER (WHERE bs.seat_no IS NOT NULL), '{}') AS seats
  FROM bookings b JOIN trips t ON t.id=b.trip_id LEFT JOIN booking_seats bs ON bs.booking_id=b.id`;
export const BOOKING_GROUP = 'GROUP BY b.id, t.id';
