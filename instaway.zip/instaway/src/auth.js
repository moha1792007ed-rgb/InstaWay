import jwt from 'jsonwebtoken';
import { config } from './config.js';
import { pool } from './db.js';
import { AppError } from './errors.js';

export const COOKIE = 'iw_admin';

export function setAuthCookie(res, admin) {
  const token = jwt.sign({ sub: admin.id, u: admin.username, role: 'admin' }, config.jwtSecret, { algorithm: 'HS256', expiresIn: '8h' });
  res.cookie(COOKIE, token, { httpOnly: true, secure: config.isProd, sameSite: 'strict', maxAge: 8 * 3600e3, path: '/api/admin' });
}

export async function requireAdmin(req, res, next) {
  try {
    const p = jwt.verify(req.cookies?.[COOKIE] ?? '', config.jwtSecret, { algorithms: ['HS256'] });
    if (p.role !== 'admin') throw new Error('role');
    // Re-check on every request so a suspended admin loses access immediately.
    const { rows } = await pool.query('SELECT username FROM admins WHERE id=$1 AND active', [p.sub]);
    if (!rows[0]) throw new Error('inactive');
    req.admin = { id: p.sub, username: rows[0].username };
    next();
  } catch {
    next(new AppError(401, 'UNAUTHENTICATED', 'سجل الدخول الأول.'));
  }
}

// CSRF defence on top of SameSite=Strict: mutating admin calls need a custom header and a same-host Origin.
export function csrfGuard(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  let sameOrigin = true;
  const origin = req.get('Origin');
  if (origin) { try { sameOrigin = new URL(origin).host === req.get('Host'); } catch { sameOrigin = false; } }
  if (req.get('X-Requested-With') !== 'InstaWay' || !sameOrigin) return next(new AppError(403, 'CSRF_BLOCKED', 'الطلب مرفوض.'));
  next();
}
