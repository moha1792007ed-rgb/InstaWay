import pg from 'pg';
import { config } from './config.js';

export const pool = new pg.Pool({
  connectionString: config.databaseUrl,
  ssl: config.pgSsl ? { rejectUnauthorized: false } : undefined,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
  statement_timeout: 10000,
});

export async function tx(fn) {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    const out = await fn(c);
    await c.query('COMMIT');
    return out;
  } catch (e) {
    try { await c.query('ROLLBACK'); } catch { /* ignore */ }
    throw e;
  } finally {
    c.release();
  }
}

export const audit = (c, { actor, action, entity, entityId, meta, ip }) =>
  c.query(
    'INSERT INTO audit_log(actor,action,entity,entity_id,meta,ip) VALUES($1,$2,$3,$4,$5,$6)',
    [actor, action, entity ?? null, entityId ?? null, meta ? JSON.stringify(meta) : null, ip ?? null]
  );
