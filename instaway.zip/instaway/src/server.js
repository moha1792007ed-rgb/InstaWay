import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { config } from './config.js';
import { pool } from './db.js';
import { publicRouter } from './routes/public.js';
import { adminRouter } from './routes/admin.js';
import { AppError, errorHandler } from './errors.js';
import { startJobs } from './jobs.js';

const app = express();
app.set('trust proxy', 1); // behind one reverse proxy (Render/Railway/Nginx): needed for correct client IPs
app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"], scriptSrc: ["'self'"], connectSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ['https://fonts.gstatic.com'], imgSrc: ["'self'", 'data:'],
      objectSrc: ["'none'"], baseUri: ["'self'"], formAction: ["'self'"], frameAncestors: ["'none'"],
      upgradeInsecureRequests: config.isProd ? [] : null,
    },
  },
}));
app.use(express.json({ limit: '10kb' }));
app.use(cookieParser());
app.use('/api', rateLimit({
  windowMs: 15 * 60_000, limit: 300, standardHeaders: true, legacyHeaders: false,
  handler: (req, res, next) => next(new AppError(429, 'RATE_LIMITED', 'محاولات كتير، استنى شوية.')),
}));
app.use('/api/admin', (req, res, next) => { res.set('Cache-Control', 'no-store'); next(); });
app.use('/api/admin', adminRouter);
app.use('/api', publicRouter);
app.use('/api', (req, res, next) => next(new AppError(404, 'NOT_FOUND', 'المسار غير موجود.')));
app.get('/healthz', async (req, res) => { try { await pool.query('SELECT 1'); res.json({ ok: true }); } catch { res.status(503).json({ ok: false }); } });
app.use(express.static(path.join(path.dirname(fileURLToPath(import.meta.url)), '../public'), { maxAge: '1h' }));
app.use(errorHandler);

export { app };
if (process.env.NODE_ENV !== 'test') {
  app.listen(config.port, () => console.log(JSON.stringify({ level: 'info', msg: `InstaWay listening on ${config.port}` })));
  startJobs();
}
