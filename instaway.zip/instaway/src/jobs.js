import { pool, tx, audit } from './db.js';
import { releaseExpiredHolds, cancelTrip } from './services.js';

// Runs every minute. An advisory lock makes it safe with several app instances.
async function tick() {
  await tx(async (c) => {
    const { rows } = await c.query('SELECT pg_try_advisory_xact_lock(727001) AS ok');
    if (!rows[0].ok) return;
    const released = await releaseExpiredHolds(c);
    // Incomplete trips: past the booking deadline and still OPEN (minimum not reached) -> cancel + refund due.
    const due = await c.query(`SELECT id FROM trips WHERE status='OPEN' AND booking_deadline <= now() FOR UPDATE`);
    for (const t of due.rows) {
      await cancelTrip(c, t.id);
      await audit(c, { actor: 'system', action: 'TRIP_AUTO_CANCELLED_MIN_NOT_REACHED', entity: 'trip', entityId: t.id });
    }
    await c.query(`UPDATE trips SET status='COMPLETED' WHERE status='CONFIRMED' AND depart_at < now() - interval '6 hours'`);
    if (released || due.rowCount) console.log(JSON.stringify({ level: 'info', job: 'tick', releasedHolds: released, cancelledTrips: due.rowCount }));
  });
}

export function startJobs() {
  const run = () => tick().catch((e) => console.error(JSON.stringify({ level: 'error', job: 'tick', msg: e.message })));
  run();
  return setInterval(run, 60_000).unref();
}
export { pool };
