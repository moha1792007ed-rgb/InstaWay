import { ZodError } from 'zod';

export class AppError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const fail = (res, status, code, message, details) =>
  res.status(status).json({ success: false, error: { code, message, ...(details ? { details } : {}) } });

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  if (err instanceof ZodError) {
    return fail(res, 400, 'VALIDATION_ERROR', 'البيانات المدخلة غير صحيحة.',
      err.issues.map((i) => ({ field: i.path.join('.'), message: i.message })));
  }
  if (err instanceof AppError) return fail(res, err.status, err.code, err.message);
  if (err.type === 'entity.parse.failed') return fail(res, 400, 'BAD_JSON', 'صيغة الطلب غير صحيحة.');
  if (err.type === 'entity.too.large') return fail(res, 413, 'PAYLOAD_TOO_LARGE', 'الطلب كبير جدًا.');
  // Server-side log only: never send internals to the client, never log request bodies.
  console.error(JSON.stringify({ level: 'error', path: req.path, method: req.method, code: err.code, msg: err.message, stack: err.stack }));
  return fail(res, 500, 'INTERNAL_ERROR', 'حصلت مشكلة عندنا، حاول تاني بعد شوية.');
}
