const need = (k) => {
  const v = process.env[k];
  if (!v) throw new Error(`Missing env ${k}`);
  return v;
};
const num = (k, d) => (process.env[k] ? Number(process.env[k]) : d);

const jwtSecret = need('JWT_SECRET');
if (jwtSecret.length < 32) throw new Error('JWT_SECRET must be at least 32 characters');

export const config = {
  isProd: process.env.NODE_ENV === 'production',
  port: num('PORT', 3000),
  databaseUrl: need('DATABASE_URL'),
  pgSsl: process.env.PGSSL === 'true',
  jwtSecret,
  walletNumber: need('WALLET_NUMBER'),
  holdMinutes: num('HOLD_MINUTES', 30),
  deadlineHoursBefore: num('DEADLINE_HOURS_BEFORE', 3),
  cancelCutoffHours: num('CANCEL_CUTOFF_HOURS', 6),
  maxPendingPerPhone: num('MAX_PENDING_PER_PHONE', 3),
  bookRateMax: num('BOOK_RATE_MAX', 10),
};
