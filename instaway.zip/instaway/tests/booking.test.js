// Integration test: needs a real PostgreSQL (DATABASE_URL), schema applied, NODE_ENV=test.
import test from 'node:test';
import assert from 'node:assert/strict';
import { app } from '../src/server.js';
import { pool } from '../src/db.js';

let server, base, tripId;
test.before(async () => {
  server = app.listen(0);
  base = `http://127.0.0.1:${server.address().port}`;
  const r = await pool.query(
    `INSERT INTO trips(origin,destination,depart_at,booking_deadline,price_egp,min_passengers)
     VALUES('ديروط','أسيوط', now()+interval '2 days', now()+interval '1 day', 40, 14) RETURNING id`);
  tripId = r.rows[0].id;
});
test.after(async () => { await pool.query('DELETE FROM trips WHERE id=$1', [tripId]).catch(() => {}); server.close(); await pool.end(); });

const book = (i, seats, key = `key-${i}-${Math.random().toString(36).slice(2)}-padpadpad`) =>
  fetch(`${base}/api/trips/${tripId}/book`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'Idempotency-Key': key },
    body: JSON.stringify({ name: 'Test User', phone: `0100000000${i}`, seats, payMethod: 'VODAFONE' }),
  });

test('only one of many concurrent bookings gets the same seat', async () => {
  const res = await Promise.all([0, 1, 2, 3, 4, 5].map((i) => book(i, [7])));
  const codes = res.map((r) => r.status).sort();
  assert.equal(codes.filter((c) => c === 201).length, 1);
  assert.ok(codes.filter((c) => c !== 201).every((c) => c === 409 || c === 429));
});

test('same idempotency key never creates a second booking', async () => {
  const key = 'idem-fixed-key-0000000001';
  const a = await book(8, [9], key), b = await book(8, [9], key);
  assert.equal(a.status, 201); assert.equal(b.status, 200);
  const { rows } = await pool.query('SELECT count(*)::int n FROM bookings WHERE idempotency_key=$1', [key]);
  assert.equal(rows[0].n, 1);
});

test('price comes from the server and admin routes need auth', async () => {
  const r = await fetch(`${base}/api/admin/bookings`, { headers: { 'X-Requested-With': 'InstaWay' } });
  assert.equal(r.status, 401);
});
