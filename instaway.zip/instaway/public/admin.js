const $=id=>document.getElementById(id);
const CITIES=['أسيوط','ديروط','القوصية','منفلوط'];
const say=m=>{$('msg').textContent=m};
async function api(path,method='GET',body){
  const r=await fetch('/api/admin'+path,{method,headers:{'Content-Type':'application/json','X-Requested-With':'InstaWay'},body:body?JSON.stringify(body):undefined});
  const j=await r.json().catch(()=>null);
  if(r.status===401&&path!=='/login'){show(false);throw new Error('سجل الدخول الأول.');}
  if(!r.ok||!j||!j.success)throw new Error((j&&j.error&&j.error.message)||'حصلت مشكلة.');
  return j.data;
}
function show(on){$('login').hidden=on;$('app').hidden=!on;}
const cell=(t)=>{const d=document.createElement('div');d.textContent=t;return d;};
const btn=(t,fn,cls)=>{const b=document.createElement('button');b.textContent=t;if(cls)b.className=cls;b.onclick=async()=>{b.disabled=true;try{await fn();say('تم.');await load();}catch(e){say(e.message);}b.disabled=false;};return b;};
const fmt=iso=>new Date(iso).toLocaleString('ar-EG',{dateStyle:'medium',timeStyle:'short'});
const NS='http://www.w3.org/2000/svg';
const el=(t,at)=>{const e=document.createElementNS(NS,t);for(const k in at)e.setAttribute(k,at[k]);return e;};
const pctTxt=v=>v==null?'—':v+'%';
function kpi(label,val,sub){const d=document.createElement('div');d.className='kpi';const s=document.createElement('small');s.textContent=label;const b=document.createElement('b');b.textContent=val;d.append(s,b);if(sub){const i=document.createElement('i');i.textContent=sub;d.append(i);}return d;}
async function loadStats(){
  const s=await api('/stats?days='+$('days').value),k=s.kpis;
  $('kpis').replaceChildren(
    kpi('إيراد مؤكد',k.revenueEgp.toLocaleString('ar-EG')+' ج'),
    kpi('الحجوزات',k.bookings,`مدفوع ${k.paid} · منتهي ${k.expired}`),
    kpi('مستني دفع',k.pending,k.awaitingReview?`${k.awaitingReview} مستني مراجعة`:''),
    kpi('نسبة الإلغاء',pctTxt(k.cancellationRatePct)),
    kpi('نسبة الإشغال',pctTxt(k.occupancyPct),'للرحلات اللي اتحركت'),
    kpi('الرحلات',k.trips,`ملغية ${k.tripsCancelled}`),
    kpi('اكتمال الرحلات',pctTxt(k.completionRatePct)),
    kpi('استردادات مستحقة',k.refundDue,k.refundDueEgp?k.refundDueEgp+' ج':''));
  const W=600,H=140,n=s.daily.length,max=Math.max(1,...s.daily.map(x=>x.revenue)),bw=W/n;
  const svg=el('svg',{viewBox:`0 0 ${W} ${H+16}`,role:'img','aria-label':'الإيراد اليومي'});
  s.daily.forEach((x,i)=>{const h=Math.round((x.revenue/max)*H);const r=el('rect',{class:'bar',x:i*bw+1,y:H-h,width:Math.max(1,bw-2),height:h});const t=el('title',{});t.textContent=`${x.day}: ${x.revenue} ج · ${x.bookings} حجز`;r.append(t);svg.append(r);});
  const l1=el('text',{class:'lbl',x:2,y:H+13});l1.textContent=s.daily[0].day;const l2=el('text',{class:'lbl',x:W-2,y:H+13,'text-anchor':'end'});l2.textContent=s.daily[n-1].day+' · أعلى يوم '+max+' ج';svg.append(l1,l2);
  $('chart').replaceChildren(svg);
  const rows=[['الخط','رحلات','إشغال','إيراد']].concat(s.routes.map(x=>[`${x.from} ← ${x.to}`,x.trips,`${x.paidSeats}/${x.capacity} (${pctTxt(x.occupancyPct)})`,x.revenueEgp+' ج']));
  $('routes').replaceChildren(...(s.routes.length?rows:[['لسه مفيش رحلات اتحركت في الفترة دي']]).map((r,i)=>{const d=document.createElement('div');d.className='rt'+(i===0&&s.routes.length?' h':'');r.forEach(c=>{const x=document.createElement('div');x.textContent=c;d.append(x);});return d;}));
}
async function load(){
  loadStats().catch(e=>say(e.message));
  const [trips,bks]=await Promise.all([api('/trips'),api('/bookings?status=PENDING_PAYMENT&limit=50')]);
  const tr=$('trips');tr.replaceChildren(...trips.map(t=>{
    const r=document.createElement('div');r.className='row';
    r.append(cell(`${t.origin} ← ${t.destination} | ${fmt(t.depart_at)} | ${t.price_egp} ج`),
      cell(`الحالة: ${t.status} | مدفوع ${t.paid_seats}/${t.capacity} (${t.occupancyPct}%) | مستني دفع ${t.pending_seats} | بتتأكد لما تتملي`));
    if(['OPEN','CONFIRMED'].includes(t.status)){const a=document.createElement('div');a.className='acts';
      a.append(btn('إلغاء الرحلة',()=>confirm('إلغاء الرحلة وتحويل المدفوع لاسترداد؟')?api(`/trips/${t.id}/cancel`,'POST'):Promise.reject(new Error('اتلغى الإجراء.')),'s'));r.append(a);}
    return r;}));
  $('bk').replaceChildren(...bks.map(b=>{
    const r=document.createElement('div');r.className='row';
    r.append(cell(`${b.code} | ${b.name} | ${b.phone} | كراسي ${b.seats.join('، ')} | ${b.total_egp} ج | ${b.pay_method}`),
      cell(`رقم العملية: ${b.pay_reference||'لسه'}`));
    const a=document.createElement('div');a.className='acts';
    a.append(btn('تأكيد الدفع',()=>api(`/bookings/${b.id}/confirm-payment`,'POST')));r.append(a);return r;}));
}
$('days').onchange=()=>loadStats().catch(e=>say(e.message));
setInterval(()=>{if(!$('app').hidden)loadStats().catch(()=>{});},60000);
$('go').onclick=async()=>{try{await api('/login','POST',{username:$('u').value,password:$('p').value});$('p').value='';show(true);await load();}catch(e){alert(e.message);}};
$('out').onclick=async()=>{await api('/logout','POST').catch(()=>{});show(false);};
for(const id of['o','d'])$(id).innerHTML=CITIES.map(c=>`<option>${c}</option>`).join('');
$('d').selectedIndex=1;
const FARES={'ديروط':40,'القوصية':30,'منفلوط':15};
const defFare=()=>FARES[$('o').value==='أسيوط'?$('d').value:$('o').value]||'';
const fillFare=()=>{$('pr').value=defFare();};
$('o').onchange=$('d').onchange=fillFare;fillFare();
$('nt').onsubmit=async e=>{e.preventDefault();
  const body={origin:$('o').value,destination:$('d').value,departAt:new Date($('at').value).toISOString(),priceEgp:+$('pr').value};
  try{await api('/trips','POST',body);say('اتضافت الرحلة.');await load();}catch(err){say(err.message);}};
api('/me').then(()=>{show(true);return load();}).catch(()=>show(false));
