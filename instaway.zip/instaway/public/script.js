const CONFIG={API_BASE:'',SUPPORT_PHONE:'',SUPPORT_WHATSAPP:''};
const CITIES=['أسيوط','ديروط','القوصية','منفلوط'];
const WALLETS=[['فودافون كاش','VODAFONE'],['اتصالات كاش','ETISALAT'],['أورنج كاش','ORANGE'],['إنستا باي','INSTAPAY']];
const LAYOUT=[['D',1,2],[3,4,5],[6,7,8],[9,10,11],[12,13,14]];
const MAX_SEATS=4;
const $=id=>document.getElementById(id);
let seats=[],pay=null,sending=false,booked=false,key=null,trips=[],trip=null,taken=[],searchN=0;

async function api(path,opt={}){
  let r;
  try{r=await fetch(CONFIG.API_BASE+path,{...opt,headers:{'Content-Type':'application/json',...(opt.headers||{})}});}
  catch{throw{message:'مفيش اتصال بالسيرفر، اتأكد من النت وحاول تاني.'};}
  const j=await r.json().catch(()=>null);
  if(!r.ok||!j||!j.success)throw{code:j&&j.error&&j.error.code,message:(j&&j.error&&j.error.message)||'حصلت مشكلة، حاول تاني.'};
  return j.data;
}
const v=id=>$(id).value.trim();
const fmtTime=iso=>new Date(iso).toLocaleTimeString('ar-EG',{hour:'2-digit',minute:'2-digit'});

['from','to'].forEach(id=>{$(id).innerHTML='<option value="">اختار مدينة أو قرية</option>'+CITIES.map(c=>`<option>${c}</option>`).join('')});
const d=new Date();$('date').min=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
$('cPhone').textContent=CONFIG.SUPPORT_PHONE||'سيتم إضافته قريبًا';$('cWa').textContent=CONFIG.SUPPORT_WHATSAPP||'سيتم إضافة الرقم قريبًا';
$('f').addEventListener('submit',e=>e.preventDefault());

$('rows').innerHTML=LAYOUT.map(r=>'<div class="row">'+r.map(x=>`<div class="cell">${x==='D'?'<div class="drv">السواق</div>':`<button type="button" class="seat" data-s="${x}" aria-pressed="false" aria-label="كرسي رقم ${x}">${x}</button>`}</div>`).join('')+'</div>').join('');
function paintSeats(){
  document.querySelectorAll('#rows .seat').forEach(b=>{
    const n=+b.dataset.s,t=taken.includes(n);
    b.disabled=t||!trip;b.style.opacity=t?'.3':'';b.style.textDecoration=t?'line-through':'';
    b.classList.toggle('on',seats.includes(n));b.setAttribute('aria-pressed',seats.includes(n));
  });
}
$('rows').addEventListener('click',e=>{
  const b=e.target.closest('.seat');if(!b)return;
  if(!trip){showErr('اختار ميعاد الرحلة الأول.');return;}
  const n=+b.dataset.s;
  if(!seats.includes(n)&&seats.length>=MAX_SEATS){showErr(`أقصى عدد كراسي في الحجز الواحد ${MAX_SEATS}.`);return;}
  seats=seats.includes(n)?seats.filter(x=>x!==n):[...seats,n].sort((a,b)=>a-b);
  showErr('');paintSeats();reset();
});
$('pay').innerHTML=WALLETS.map(w=>`<button type="button" data-p="${w[1]}">${w[0]}</button>`).join('');
$('pay').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;pay={code:b.dataset.p,label:b.textContent};
  [...$('pay').children].forEach(x=>x.classList.toggle('on',x===b));
  $('payNote').classList.remove('hide');$('payNote').textContent=`هتظهرلك بيانات التحويل بعد تأكيد الحجز (${pay.label}).`;reset();});
$('f').addEventListener('input',e=>{if(!e.target.closest('#done'))reset();});
['from','to'].forEach(id=>$(id).addEventListener('change',()=>{const o=id==='from'?'to':'from';if(!$(o).value&&$(id).value&&$(id).value!=='أسيوط')$(o).value='أسيوط';}));
['from','to','date'].forEach(id=>$(id).addEventListener('change',loadTrips));
$('time').addEventListener('change',onTripChange);

const unit=()=>trip?trip.priceEgp:0;
function reset(){key=null;$('done').classList.add('hide');if(booked){booked=false;$('submit').classList.remove('hide');}refresh();}
function refresh(){
  $('seatLabel').textContent=seats.length?(seats.length>1?'كراسي رقم ':'كرسي رقم ')+seats.join('، ')+' ('+seats.length+')':'لسه ماختارتش';
  $('priceTxt').textContent=trip?(seats.length?`${unit()*seats.length} جنيه (${seats.length} × ${unit()})`:`${unit()} جنيه للكرسي`):'اختار الرحلة الأول';
  const tl=trip?`${$('date').value} الساعة ${fmtTime(trip.departAt)}`:'';
  $('summary').textContent=`الاسم: ${v('name')}\nالتليفون: ${v('phone')}\nالرحلة: من ${v('from')} إلى ${v('to')}\nالموعد: ${tl}\nالكراسي: ${seats.join('، ')} (${seats.length})\nالإجمالي: ${unit()*seats.length} جنيه`;
}
async function loadTrips(){
  const n=++searchN;trip=null;taken=[];seats=[];paintSeats();reset();
  const sel=$('time'),f=v('from'),t=v('to'),dt=v('date');
  const msg=m=>{sel.innerHTML=`<option value="">${m}</option>`};
  if(!f||!t||!dt)return msg('اختار من/إلى والتاريخ الأول');
  if(f===t)return msg('مكان التحرك والوصول لازم يكونوا مختلفين');
  if(f!=='أسيوط'&&t!=='أسيوط')return msg('لازم أسيوط تكون نقطة التحرك أو الوصول');
  msg('جاري البحث...');
  try{
    const r=await api(`/api/trips?from=${encodeURIComponent(f)}&to=${encodeURIComponent(t)}&date=${dt}`);
    if(n!==searchN)return;trips=r;
    sel.innerHTML=r.length?'<option value="">اختار ميعاد الرحلة</option>':'<option value="">مفيش رحلات متاحة في اليوم ده</option>';
    r.forEach(x=>{const o=document.createElement('option');o.value=x.id;o.textContent=`${fmtTime(x.departAt)} — ${x.seatsFree} كرسي متاح — ${x.priceEgp} جنيه`;if(x.seatsFree<1){o.disabled=true;o.textContent=`${fmtTime(x.departAt)} — اكتمل العدد`;}sel.appendChild(o);});
  }catch(e){if(n===searchN){msg('تعذر تحميل الرحلات');showErr(e.message);}}
}
async function onTripChange(){
  seats=[];taken=[];trip=trips.find(x=>x.id===$('time').value)||null;paintSeats();reset();
  if(!trip)return;
  try{taken=(await api(`/api/trips/${trip.id}/seats`)).taken;}catch(e){showErr(e.message);}
  paintSeats();
}
function validate(needPay){
  if(!v('from')||!v('to'))return'من فضلك اختار مدينة التحرك والوصول.';
  if(v('from')===v('to'))return'مكان التحرك والوصول لازم يكونوا مختلفين.';
  if(!v('date'))return'من فضلك حدد تاريخ التحرك.';
  if(!trip)return'من فضلك اختار ميعاد الرحلة.';
  if(v('name').length<2)return'من فضلك اكتب اسمك.';
  if(!/^01[0125]\d{8}$/.test(v('phone')))return'اكتب رقم تليفون صحيح من ١١ رقم يبدأ بـ 01.';
  if(!seats.length)return'من فضلك اختار كرسي واحد على الأقل من شكل العربية.';
  if(needPay&&!pay)return'من فضلك اختار طريقة الدفع.';
  return'';
}
function showErr(m){$('err').textContent=m;$('err').classList.toggle('hide',!m)}
$('confirm').onclick=()=>{const m=validate(false);showErr(m);if(m)return;refresh();
  $('step2').classList.remove('hide');$('step2').style.display='flex';$('confirm').classList.add('hide');$('submit').classList.remove('hide');};
$('submit').onclick=async()=>{
  const m=validate(true);showErr(m);if(m||sending)return;
  key=key||crypto.randomUUID(); // same key on retry of the same form => server never creates a duplicate
  const body={name:v('name'),phone:v('phone'),seats:[...seats],payMethod:pay.code};
  sending=true;$('submit').disabled=true;$('submit').textContent='جاري الإرسال...';
  try{
    const r=await api(`/api/trips/${trip.id}/book`,{method:'POST',headers:{'Idempotency-Key':key},body:JSON.stringify(body)});
    showBooked(r,body);showErr('');booked=true;$('submit').classList.add('hide');
    onTripChange.keepDone=true;
    try{taken=(await api(`/api/trips/${trip.id}/seats`)).taken;seats=[];paintSeats();}catch{}
  }catch(e){
    showErr(e.message);
    if(e.code==='SEAT_TAKEN'){try{taken=(await api(`/api/trips/${trip.id}/seats`)).taken;seats=seats.filter(s=>!taken.includes(s));paintSeats();refresh();key=null;}catch{}}
  }
  sending=false;$('submit').disabled=false;$('submit').textContent='إتمام الحجز';
};
function showBooked(r,body){
  const dn=$('done');dn.textContent='';
  const p=document.createElement('p');
  p.textContent=`شكرًا يا ${body.name}، كراسيك (${r.booking.seats.join('، ')}) محجوزة مؤقتًا لمدة ${r.payment.holdMinutes} دقيقة. كود حجزك: ${r.booking.code} (احتفظ بيه). حوّل ${r.payment.amountEgp} جنيه عن طريق ${pay.label} على الرقم ${r.payment.wallet}، وبعدها اكتب رقم العملية هنا. الحجز بيتأكد بعد مراجعة التحويل.`;
  const inp=document.createElement('input');inp.type='text';inp.placeholder='رقم عملية التحويل';inp.maxLength=40;inp.style.cssText='margin-top:10px;width:100%';
  const btn=document.createElement('button');btn.type='button';btn.className='btn';btn.textContent='إرسال رقم العملية';btn.style.marginTop='8px';
  const st=document.createElement('div');st.setAttribute('role','status');
  btn.onclick=async()=>{
    try{await api(`/api/bookings/${r.booking.code}/payment`,{method:'POST',body:JSON.stringify({phone:body.phone,reference:inp.value.trim()})});st.textContent='وصلنا رقم العملية، هنراجعه ونتواصل معاك.';}
    catch(e){st.textContent=e.message;}
  };
  dn.append(p,inp,btn,st);dn.classList.remove('hide');
}

/* ====== شرح الحجز ====== */
const VT=[['اختار مكان التحرك','دوس على خانة "من"، واختار البلد اللي هتتحرك منها.'],['اختار وجهتك','دوس على خانة "إلى"، واختار البلد اللي رايحها.'],['حدد اليوم والوقت','اختار تاريخ السفر، وبعدين ميعاد التحرك اللي يناسبك.'],['اكتب اسمك وتليفونك','اكتب اسمك، ورقم تليفونك اللي هنتصل بيك عليه.'],['اختار كرسيك','دوس على الكرسي اللي عايزه من شكل العربية. ممكن تختار أكتر من كرسي.'],['راجع بياناتك','دوس على زر تأكيد البيانات، وراجع كل حاجة كتبتها.'],['ادفع وخلاص','اختار المحفظة اللي هتدفع بيها وحوّل المبلغ، وبعدها هنتصل بيك.']];
const VF=[['من','أسيوط'],['إلى','ديروط'],['التاريخ والوقت','٢٠ نوفمبر، الساعة ٨:٠٠ ص'],['الاسم والتليفون','اسمك، 01XXXXXXXXX']];
let vi=0,vPlaying=false,vVoice=false,vTimer=null;
$('vDots').innerHTML=VT.map((_,k)=>`<button type="button" class="d" data-k="${k}" aria-label="خطوة ${k+1}"></button>`).join('');
function vSpeak(){try{const w=window.speechSynthesis;if(!w)return;w.cancel();const u=new SpeechSynthesisUtterance(VT[vi][0]+'. '+VT[vi][1]);u.lang='ar-EG';u.rate=.9;w.speak(u)}catch(e){}}
function vStop(){try{window.speechSynthesis.cancel()}catch(e){}}
function vRender(){
  $('vNum').textContent=vi+1;$('vTitle').textContent=VT[vi][0];$('vText').textContent=VT[vi][1];
  $('vBar').style.width=Math.round((vi+1)/7*100)+'%';
  [...$('vDots').children].forEach((d,k)=>d.classList.toggle('on',k===vi));
  let h='';
  if(vi<4)h=`<div class="vf"><div>${VF[vi][0]}</div><div class="val pulse">${VF[vi][1]}</div></div>`;
  else if(vi===4)h='<div class="ms">'+Array.from({length:14},(_,k)=>`<i class="${k===4||k===5?'on pulse':''}"></i>`).join('')+'</div><div style="font-weight:600;text-align:center">دوس على الكرسي اللي عايزه (ممكن أكتر من كرسي)</div>';
  else if(vi===5)h='<div class="vbtn pulse">تأكيد البيانات</div>';
  else h='<div class="vw"><span class="on pulse">فودافون كاش</span><span>اتصالات كاش</span><span>أورنج كاش</span><span>إنستا باي</span></div>';
  $('vPanel').innerHTML=h;
  $('vPlay').textContent=vPlaying?'إيقاف الشرح':(vi===0?'▶ شغّل الشرح':'▶ كمّل الشرح');
  $('vVoice').textContent=vVoice?'الصوت: شغال':'الصوت: مقفول (دوس عشان تسمع)';
}
function vGo(k){vi=(k+7)%7;vRender();if(vVoice)vSpeak();}
$('vPlay').onclick=()=>{vPlaying=!vPlaying;clearInterval(vTimer);
  if(vPlaying){vTimer=setInterval(()=>vGo(vi+1),7000);if(vVoice)vSpeak();}else vStop();vRender();};
$('vVoice').onclick=()=>{vVoice=!vVoice;if(vVoice)vSpeak();else vStop();vRender();};
$('vPrev').onclick=()=>vGo(vi-1);$('vNext').onclick=()=>vGo(vi+1);
$('vDots').onclick=e=>{const b=e.target.closest('.d');if(b)vGo(+b.dataset.k)};
vRender();
