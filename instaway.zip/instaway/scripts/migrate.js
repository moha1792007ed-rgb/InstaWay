import fs from 'node:fs';
import pg from 'pg';
const c = new pg.Client({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : undefined });
await c.connect();
await c.query(fs.readFileSync(new URL('../schema.sql', import.meta.url), 'utf8'));
await c.end();
console.log('schema applied');
