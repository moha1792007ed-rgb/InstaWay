// usage: ADMIN_PASSWORD='long-password' npm run admin:create -- username
import bcrypt from 'bcryptjs';
import pg from 'pg';
const username = process.argv[2];
const password = process.env.ADMIN_PASSWORD;
if (!username || !password || password.length < 12) {
  console.error('Need a username argument and ADMIN_PASSWORD env (min 12 chars).');
  process.exit(1);
}
const c = new pg.Client({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : undefined });
await c.connect();
const hash = await bcrypt.hash(password, 12);
await c.query(
  `INSERT INTO admins(username,password_hash) VALUES($1,$2)
   ON CONFLICT (username) DO UPDATE SET password_hash=$2, failed_attempts=0, locked_until=NULL, active=true`,
  [username, hash]
);
await c.end();
console.log('admin ready:', username);
